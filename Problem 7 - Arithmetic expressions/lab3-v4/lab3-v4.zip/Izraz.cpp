#include "Izraz.h"

Izraz::Izraz()
{
}
